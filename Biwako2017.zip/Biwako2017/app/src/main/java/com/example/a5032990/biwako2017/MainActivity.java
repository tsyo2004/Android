package com.example.a5032990.biwako2017;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.TextView;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Spinner;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {

    private final static int RESULT_CAMERA = 1001;
    private final static int REQUEST_PERMISSION = 1002;

    private ImageView imageView;
    private Uri cameraUri;
    private File  cameraFile;
    private String filePath,filePath2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Button camera_button;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (savedInstanceState != null){
            cameraUri = savedInstanceState.getParcelable("CaptureUri");
        }

        imageView = (ImageView)findViewById(R.id.image_view);

        Button cameraButton = (Button)findViewById(R.id.camera_button);
        Button clearButton = (Button) findViewById(R.id.clear_button);

        cameraButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Android 6, API 23以上でパーミッシンの確認
                if (Build.VERSION.SDK_INT >= 23) {
                    checkPermission();
                }
                else {
                    cameraIntent();
                }
            }
        });
        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText e;
                Spinner s;
                e = (EditText) findViewById(R.id.editText2);
                e.getEditableText().clear();
                e = (EditText) findViewById(R.id.editText4);
                e.getEditableText().clear();
                e = (EditText) findViewById(R.id.editText5);
                e.getEditableText().clear();
                e = (EditText) findViewById(R.id.editText6);
                e.getEditableText().clear();
                e = (EditText) findViewById(R.id.editText3);
                e.getEditableText().clear();
                s = (Spinner) findViewById(R.id.spinner5);
                s.setSelection(0);
                s = (Spinner) findViewById(R.id.spinner1);
                s.setSelection(0);
                s = (Spinner) findViewById(R.id.spinner7);
                s.setSelection(0);
                s = (Spinner) findViewById(R.id.spinner8);
                s.setSelection(0);
                s = (Spinner) findViewById(R.id.spinner9);
                s.setSelection(0);
                s = (Spinner) findViewById(R.id.spinner6);
                s.setSelection(0);
                imageView.setImageURI(null);

                Toast.makeText(MainActivity.this, "値を初期化しました", Toast.LENGTH_LONG).show();
            }
        });
    }

    protected void onSaveInstanceState(Bundle outState){
        outState.putParcelable("CaptureUri", cameraUri);
    }

    private void cameraIntent() {
        int QNum;

        // 保存先のフォルダーを作成
        File cameraFolder = new File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "IMG"
        );
        cameraFolder.mkdirs();

        // 保存ファイル名
        String fileName = new SimpleDateFormat("ddHHmmss").format(new Date());
        filePath = cameraFolder.getPath() + "/" + fileName + ".jpg";
        Log.d("debug", "filePath:" + filePath);

        // capture画像のファイルパス
        cameraFile = new File(filePath);
//        cameraUri = Uri.fromFile(cameraFile);
        cameraUri = FileProvider.getUriForFile(MainActivity.this, getApplicationContext().getPackageName() + ".provider", cameraFile);

        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
        startActivityForResult(intent, RESULT_CAMERA);

// アンケート結果を保存
        if (isExternalStorageWritable()) {
            FileOutputStream os;

            // ※以下、例外処理は省略

            // パブリックディレクトリにファイルを作成し、書き込む。
            filePath2 = cameraFolder.getPath() + "/" + fileName + ".csv";
            String fileName2 = fileName + ".csv";
            File fw = new File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), fileName2);
            String fn0 = fw.getAbsolutePath();
            Log.d("debug", "filePath:" + filePath2);

            try {
                //出力先を作成する
                os = new FileOutputStream(fw);
                OutputStreamWriter pw = new OutputStreamWriter(os);
                BufferedWriter bw = new BufferedWriter(pw);
//                FileOutputStream fw = new FileOutputStream(filePath2, true);
//                FileOutputStream fw = openFileOutput(fileName2, MODE_PRIVATE);
//                FileWriter fw = new FileWriter(filePath2, false);
//                PrintWriter pw = new PrintWriter(new BufferedWriter(fw));

                // 業界
                Spinner spinner = (Spinner) findViewById(R.id.spinner5);
                int idx = spinner.getSelectedItemPosition();
                String item = (String) spinner.getSelectedItem();
                EditText editText = (EditText) findViewById(R.id.editText2);
                String text = editText.getText().toString();
                bw.write("業種,");
                bw.write(idx);
                bw.write(",");
                bw.write(item);
                bw.write(",");
                bw.write(text);
                bw.write(",");

                // 適用工程
                spinner = (Spinner) findViewById(R.id.spinner1);
                idx = spinner.getSelectedItemPosition();
                item = (String) spinner.getSelectedItem();
                editText = (EditText) findViewById(R.id.editText4);
                text = editText.getText().toString();
                bw.write("適用工程,");
                bw.write(idx);
                bw.write(",");
                bw.write(item);
                bw.write(",");
                bw.write(text);
                bw.write(",");

                // 適用状況
                spinner = (Spinner) findViewById(R.id.spinner7);
                idx = spinner.getSelectedItemPosition();
                item = (String) spinner.getSelectedItem();
                editText = (EditText) findViewById(R.id.editText5);
                text = editText.getText().toString();
                bw.write("適用状況,");
                bw.write(idx);
                bw.write(",");
                bw.write(item);
                bw.write(",");
                bw.write(text);
                bw.write(",");

                // 効果
                spinner = (Spinner) findViewById(R.id.spinner8);
                idx = spinner.getSelectedItemPosition();
                item = (String) spinner.getSelectedItem();
                editText = (EditText) findViewById(R.id.editText6);
                text = editText.getText().toString();
                bw.write("効果,");
                bw.write(idx);
                bw.write(",");
                bw.write(item);
                bw.write(",");
                bw.write(text);
                bw.write(",");

                // 金額
                spinner = (Spinner) findViewById(R.id.spinner9);
                idx = spinner.getSelectedItemPosition();
                item = (String) spinner.getSelectedItem();
                editText = (EditText) findViewById(R.id.editText3);
                text = editText.getText().toString();
                bw.write("金額,");
                bw.write(idx);
                bw.write(",");
                bw.write(item);
                bw.write(",");
                bw.write(text);
                bw.write(",");

                // 期待
                spinner = (Spinner) findViewById(R.id.spinner6);
                idx = spinner.getSelectedItemPosition();
                item = (String) spinner.getSelectedItem();
                bw.write("期待,");
                bw.write(idx);
                bw.write(",");
                bw.write(item);
                bw.newLine();

                //ファイルに書き出す
                bw.flush();
                bw.close();

                // アンケート件数読み書き
                try{
                    FileInputStream in = openFileInput( "Num.txt" );
                    BufferedReader reader = new BufferedReader( new InputStreamReader( in , "UTF-8") );
                    String str = reader.readLine();
                    reader.close();
                    QNum = Integer.parseInt(str);
                }catch( IOException e ){
                    e.printStackTrace();
                    QNum = 0;
                }
                QNum++;
                try{
                    String str = String.valueOf(QNum);
                    FileOutputStream out = openFileOutput( "Num.txt", MODE_PRIVATE );
                    out.write( str.getBytes() );
                    out.close();
                }catch( IOException e ){
                    e.printStackTrace();
                }

                Toast.makeText(MainActivity.this, "Saveしました："+QNum+"件", Toast.LENGTH_LONG).show();
                TextView textView = (TextView) findViewById(R.id.textView10);
                textView.setText(String.format("%4d",QNum));


            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /* Checks if external storage is available for read and write */
    public boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            return true;
        }
        return false;
    }

    /* Checks if external storage is available to at least read */
    public boolean isExternalStorageReadable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state) ||
                Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
            return true;
        }
        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        if (requestCode == RESULT_CAMERA) {

            if(cameraUri != null){
                imageView.setImageURI(cameraUri);
                //　
                registerDatabase(filePath);
            }
            else{
                Log.d("debug","cameraUri == null");
            }
        }
    }

    // アンドロイドのデータベースへ登録する
    private void registerDatabase(String file) {
        ContentValues contentValues = new ContentValues();
        ContentResolver contentResolver = MainActivity.this.getContentResolver();
        contentValues.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        contentValues.put("_data", file);
        contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,contentValues);
    }

    // Runtime Permission check
    private void checkPermission(){
        // 既に許可している
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED){
            cameraIntent();
        }
        // 拒否していた場合
        else{
            requestLocationPermission();
        }
    }

    // 許可を求める
    private void requestLocationPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_PERMISSION);

        } else {
            Toast toast = Toast.makeText(this, "許可されないとアプリが実行できません", Toast.LENGTH_SHORT);
            toast.show();

            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,}, REQUEST_PERMISSION);

        }
    }

    // 結果の受け取り
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQUEST_PERMISSION) {
            // 使用が許可された
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                cameraIntent();
                return;

            } else {
                // それでも拒否された時の対応
                Toast toast = Toast.makeText(this, "これ以上なにもできません", Toast.LENGTH_SHORT);
                toast.show();
            }
        }
    }


}
